# Student Number: 18071472 18017060 21104272 21047887
def split_data(data_path, train_ratio=0.6,test_ratio=0.2, candidate_answers=['Positive','Negative']):
    
    all_data =[]

    #categories is used to count the total number of label
    categories = set()
    with open(data_path, 'r', encoding="UTF-8") as f:
            # sentiment: 0 is positive, 1 is negative
            # sentence is the sentence from tsv
            
            for line in f:
                sentiment, sentence = line.split("\t")
                categories.add(sentiment)
                
                all_data.append((sentence[:-1],'\t',candidate_answers[0],'\t',sentiment,'\n'))
                if sentiment=="1":
                    all_data.append((sentence[:-1],'\t',candidate_answers[1],'\t',"0",'\n'))
                if sentiment=="0":
                    all_data.append((sentence[:-1],'\t',candidate_answers[1],'\t',"1",'\n'))
    length = len(all_data)
    train_nums = int(length * train_ratio)
    test_nums=train_nums+int(length*test_ratio)
    train_data = all_data[:train_nums]
    test_data=all_data[train_nums:test_nums]
    val_data = all_data[test_nums:]
    with open("train.csv",'w', encoding="UTF-8") as f:
        for i in train_data:
            f.writelines(i)
    with open("test.csv",'w', encoding="UTF-8") as f:
        for j in test_data:
            f.writelines(j)
    with open("val.csv",'w', encoding="UTF-8") as f:
        for k in val_data:
            f.writelines(k)

    return train_data, test_data, val_data, categories


split_data(data_path="sst2_shuffled.tsv", candidate_answers=['True', 'False'])

